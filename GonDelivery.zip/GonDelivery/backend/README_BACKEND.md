# Backend Gon Delivery (Firebase)

O que já está pronto:
- `firestore.rules`: clientes só leem catálogo e os PRÓPRIOS pedidos; ninguém grava pedido direto.
- `functions/src/index.ts`:
  - `createOrder`: recalcula preço/total no servidor, bloqueia vale-refeição em bebida alcoólica,
    cria o pedido e chama `createCharge` (ponto de integração do pagamento).
  - `paymentWebhook`: confirma pagamento só com segredo válido e valor igual ao total.
- App Android: `Backend.kt` (login anônimo, catálogo do Firestore, criar pedido) e escolha da forma
  de pagamento no carrinho (Pix, Cartão, Vale-refeição, GonPay, Bitcoin, GonCoin).

O que AINDA FALTA (precisa de contas e contratos seus):
1. Integrar o provedor de pagamento em `createCharge` (Pix, cartão/vale, GonPay, cripto).
2. Trocar login anônimo por e-mail/telefone e exigir data de nascimento 18+ (TODO no código).
3. Painel/app do lojista (restaurantes, com cardápio e horário) e do entregador; status do pedido em tempo real no app.

## Passo a passo
1. console.firebase.google.com > Criar projeto.
2. Adicionar app Android com o pacote `com.gon.delivery` (ou o seu applicationId) e o SHA-1
   da sua chave. Baixe `google-services.json` e coloque em `app/` (pasta do módulo).
3. Authentication > Método de login > ative "Anônimo" (depois, e-mail/telefone).
4. Firestore Database > Criar banco, região `southamerica-east1` (São Paulo).
5. Cloud Functions exige o plano Blaze (pago por uso; tem cota gratuita).
6. No computador (Node 20):
   ```
   npm i -g firebase-tools
   firebase login
   cd backend
   firebase use --add            # escolha o projeto
   cd functions && npm install && cd ..
   firebase functions:secrets:set WEBHOOK_SECRET   # invente um segredo longo
   firebase deploy
   ```
7. Cadastrar produtos de exemplo: `cd functions && GOOGLE_CLOUD_PROJECT=<id> npm run seed`
   (ou crie a coleção `products` no console com: name, price, category, alcoholic, active).
8. Abra o app no Android Studio e rode. Com `google-services.json` presente, o catálogo
   vem do Firestore e o pedido é criado pela função `createOrder`.

## Painel do lojista (restaurantes e lojas)
Pasta `lojista/` = site simples (Firebase Hosting) com pedidos em tempo real e cardápio.
1. Console Firebase > Configurações do projeto > Seus apps > Web: registre um app Web e
   cole a configuração em `lojista/index.html` (`firebaseConfig`).
2. Authentication: ative "E-mail/senha".
3. Para cada loja parceira (depois de conferir CNPJ e alvará sanitário):
   - Authentication > Users > Adicionar usuário (e-mail e senha do lojista) e copie o UID;
   - Firestore > coleção `stores` > documento com campos: `name`, `ownerUid` (UID),
     `approved` = true, `open` = true. O ID do documento é o ID da loja.
4. `firebase deploy` (publica regras, índices, funções e o site). Endereço:
   `https://SEU-PROJETO.web.app`.
5. O lojista entra, cadastra os produtos (a loja só mexe nos próprios) e aceita os pedidos
   pagos. Ele só altera o STATUS do pedido, nunca valores.
Cancelar um pedido pago NÃO devolve o dinheiro sozinho: faça o estorno no provedor.
Cada pedido vale para UMA loja; o app ainda mistura lojas no carrinho (próximo ajuste).

## Provedores de pagamento (você escolhe e contrata)
- Pix e cartão: um banco/PSP com API (ex.: Mercado Pago, Asaas, Pagar.me, Efí, Stripe).
- Vale-refeição: adquirente/PSP que aceite as operadoras (Alelo, Sodexo, Ticket, VR...).
- Bitcoin/GonCoin: processador cripto licenciado ou servidor próprio (ex.: BTCPay Server).
- GonPay: regras suas (veja os alertas de Banco Central/Play em PLAY_STORE/05).
Cada provedor assina o webhook de um jeito: adapte a verificação em `paymentWebhook`
e envie o URL da função `paymentWebhook` no painel do provedor.

## Segurança (não pule)
- Nunca coloque chaves do provedor no app: use `defineSecret` nas Functions.
- Confirme pagamento SÓ pelo webhook (servidor), nunca pelo app.
- Não guarde número de cartão, chave privada ou frase de recuperação de carteira.
- Faça backup da chave `.jks` e do projeto Firebase (proprietários extras no console).
