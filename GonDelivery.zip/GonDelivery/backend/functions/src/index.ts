import { onCall, onRequest, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { timingSafeEqual } from "crypto";

initializeApp();
const db = getFirestore();

const REGION = "southamerica-east1";
const DELIVERY_FEE_CENTS = 500; // R$ 5,00 (depois: por loja/distância)
const METHODS = ["pix", "cartao", "vale", "gonpay", "bitcoin", "goncoin"];
const webhookSecret = defineSecret("WEBHOOK_SECRET");

/**
 * Cria o pedido. O PREÇO NUNCA vem do app: tudo é recalculado aqui.
 * Entrada: { items: [{productId, qty}], paymentMethod }
 * Saída:   { orderId, totalCents, instructions }
 */
export const createOrder = onCall({ region: REGION }, async (req) => {
  if (!req.auth) throw new HttpsError("unauthenticated", "Faça login.");

  const method = String(req.data?.paymentMethod ?? "");
  if (!METHODS.includes(method)) {
    throw new HttpsError("invalid-argument", "Forma de pagamento inválida.");
  }

  const raw: unknown[] = Array.isArray(req.data?.items) ? req.data.items : [];
  if (raw.length === 0 || raw.length > 50) {
    throw new HttpsError("invalid-argument", "Itens inválidos.");
  }
  const items = raw.map((i: any) => ({
    productId: String(i?.productId ?? ""),
    qty: Math.floor(Number(i?.qty)),
  }));
  const ids = items.map((i) => i.productId);
  if (
    items.some((i) => !i.productId || !(i.qty >= 1 && i.qty <= 50)) ||
    new Set(ids).size !== ids.length
  ) {
    throw new HttpsError("invalid-argument", "Itens inválidos.");
  }

  const snaps = await db.getAll(...ids.map((id) => db.collection("products").doc(id)));
  let subtotalCents = 0;
  let hasAlcohol = false;
  const lines = snaps.map((s, idx) => {
    const d = s.data();
    if (!s.exists || !d || d.active !== true) {
      throw new HttpsError("failed-precondition", "Produto indisponível.");
    }
    const unitCents = Math.round(Number(d.price) * 100);
    if (!Number.isFinite(unitCents) || unitCents <= 0) {
      throw new HttpsError("failed-precondition", "Preço inválido.");
    }
    if (d.alcoholic === true) hasAlcohol = true;
    subtotalCents += unitCents * items[idx].qty;
    return { productId: s.id, storeId: String(d.storeId ?? ""), name: String(d.name), unitCents, qty: items[idx].qty };
  });

  // Um pedido pertence a UMA loja, aprovada e aberta.
  const storeIds = new Set(lines.map((l) => l.storeId));
  if (storeIds.size !== 1 || storeIds.has("")) {
    throw new HttpsError("failed-precondition", "Um pedido só pode ter itens de uma loja.");
  }
  const storeId = [...storeIds][0];
  const storeSnap = await db.collection("stores").doc(storeId).get();
  const store = storeSnap.data();
  if (!storeSnap.exists || !store || store.approved !== true || store.open === false) {
    throw new HttpsError("failed-precondition", "Loja indisponível no momento.");
  }

  // Vale-refeição/alimentação não pode comprar bebida alcoólica.
  if (method === "vale" && hasAlcohol) {
    throw new HttpsError(
      "failed-precondition",
      "Vale-refeição não vale para bebida alcoólica."
    );
  }

  // TODO (maioridade): exigir data de nascimento verificada em users/{uid} para hasAlcohol.

  const totalCents = subtotalCents + DELIVERY_FEE_CENTS;
  const ref = db.collection("orders").doc();
  await ref.set({
    uid: req.auth.uid,
    storeId,
    items: lines,
    subtotalCents,
    deliveryFeeCents: DELIVERY_FEE_CENTS,
    totalCents,
    paymentMethod: method,
    hasAlcohol,
    status: "aguardando_pagamento",
    createdAt: FieldValue.serverTimestamp(),
  });

  const instructions = await createCharge(ref.id, totalCents, method);
  return { orderId: ref.id, totalCents, instructions };
});

/**
 * PONTO DE INTEGRAÇÃO COM O PROVEDOR DE PAGAMENTO.
 * Cada case deve criar a cobrança no provedor escolhido e devolver o texto
 * que o cliente vê (ex.: Pix "copia e cola", link de checkout, endereço de
 * pagamento cripto). Enquanto não houver provedor, devolve aviso claro.
 * Guarde chaves do provedor em secrets (defineSecret), nunca no app.
 */
async function createCharge(
  orderId: string,
  totalCents: number,
  method: string
): Promise<string> {
  switch (method) {
    case "pix":
      // TODO: criar cobrança Pix (API do seu banco/PSP) e retornar o "copia e cola".
      break;
    case "cartao":
    case "vale":
      // TODO: criar checkout/transação no adquirente (cartão e operadoras de vale).
      break;
    case "gonpay":
      // TODO: debitar saldo/carteira GonPay (regras definidas por você).
      break;
    case "bitcoin":
    case "goncoin":
      // TODO: gerar endereço/fatura em um processador cripto; fixar cotação por alguns minutos.
      break;
  }
  void orderId;
  void totalCents;
  return "Pedido criado. Pagamento pendente: provedor ainda não configurado.";
}

/**
 * Webhook do provedor. Marca o pedido como pago SÓ se o segredo confere e o
 * valor pago é igual ao total do pedido. Adapte a verificação à assinatura
 * do seu provedor (a maioria assina o corpo com HMAC).
 * Corpo esperado: { orderId, status: "paid", amountCents }
 */
export const paymentWebhook = onRequest(
  { region: REGION, secrets: [webhookSecret] },
  async (req, res) => {
    if (req.method !== "POST") {
      res.status(405).send("Method not allowed");
      return;
    }
    const got = Buffer.from(String(req.get("x-webhook-secret") ?? ""));
    const want = Buffer.from(webhookSecret.value());
    if (got.length !== want.length || !timingSafeEqual(got, want)) {
      res.status(401).send("Unauthorized");
      return;
    }

    const { orderId, status, amountCents } = req.body ?? {};
    if (typeof orderId !== "string" || status !== "paid") {
      res.status(400).send("Bad request");
      return;
    }

    const ref = db.collection("orders").doc(orderId);
    const result = await db.runTransaction(async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists) return 404;
      const o = snap.data()!;
      if (o.status !== "aguardando_pagamento") return 200; // idempotente
      if (Number(amountCents) !== o.totalCents) return 409; // valor não confere
      tx.update(ref, { status: "pago", paidAt: FieldValue.serverTimestamp() });
      return 200;
    });
    res.sendStatus(result);
  }
);
