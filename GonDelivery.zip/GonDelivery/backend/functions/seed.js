// Uso: (na pasta functions) GOOGLE_CLOUD_PROJECT=seu-projeto node seed.js
// Requer credenciais: `gcloud auth application-default login`
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();
const products = require("./seed-products.json");
(async () => {
  const batch = db.batch();
  // Loja de demonstração: troque ownerUid pelo UID do usuário lojista (Authentication > Users).
  batch.set(db.collection("stores").doc("loja-demo"), {
    name: "Loja Demo", ownerUid: "COLE_O_UID_DO_LOJISTA", approved: true, open: true,
  });
  for (const { id, ...data } of products) batch.set(db.collection("products").doc(id), data);
  await batch.commit();
  console.log("Produtos criados:", products.length);
})();
