# Ficha da loja (pt-BR) - ajuste ao que o app REALMENTE faz

Nome (máx. 30): gon.delivery
Descrição curta (máx. 80):
Peça comida e bebidas e acompanhe a entrega até a sua porta.

Descrição completa:
O gon.delivery conecta você a lojas e distribuidores da sua região para
receber comida, bebidas e itens de conveniência onde estiver.

- Escolha lanches, pizzas, marmitas, bebidas e mais, por categoria
- Monte o carrinho e veja o total com a taxa de entrega
- Acompanhe o status do pedido
- Pague com GonPay, Pix, cartões, vale-refeição (apenas itens sem álcool), Bitcoin e GonCoin
- Venda exclusiva para maiores de 18 anos

Venda de bebidas alcoólicas proibida para menores de 18 anos.
Beba com moderação.

Categoria: Comida e bebida
Tags sugeridas: delivery, comida, bebidas, entregas
E-mail de contato: [SEU E-MAIL]
Site: https://sites.google.com/view/gondelivery
WhatsApp: +55 (21) 99023-8138 / +55 (21) 97976-3767

Pagamentos: liste na ficha só o que já funciona de verdade no app. Não escreva
promessas de valorização ou lucro sobre GonCoin/Bitcoin ("invista", "vai valorizar").

IMPORTANTE: não descreva recursos que o app ainda não tem (pagamento real,
rastreio em mapa etc.). Descrição enganosa é motivo comum de rejeição.
Não use nome, logo, cores ou textos do Zé Delivery ou de outras marcas.
