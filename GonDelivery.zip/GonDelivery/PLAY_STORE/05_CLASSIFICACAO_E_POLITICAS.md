# Classificação, público-alvo e políticas

Público-alvo e conteúdo: marque apenas 18 anos ou mais (não "Crianças").
Questionário de classificação de conteúdo: responda que o app permite
a venda/entrega de bebidas alcoólicas (categoria de álcool, tabaco e drogas).
Anúncios: não (se não usar).
Acesso ao app: se houver login, informe e-mail e senha de teste para o revisor.
Aplicativo de notícias/governo/saúde/finanças: não.

Álcool: aplicativos que facilitam a venda de bebidas alcoólicas estão sujeitos
às políticas de conteúdo restrito do Google Play e à lei local. Leia a política
atual no Play Console (Política > Conteúdo restrito) e mantenha:
- confirmação de 18+ no app e checagem de idade também na entrega;
- venda apenas em regiões e por lojistas autorizados (alvará, CNPJ).

Marca: não use nomes, logos ou cores de terceiros (Zé Delivery, Google etc.).
Funcionalidade mínima: o app precisa funcionar de ponta a ponta (login,
pedido real, pagamento). Apps de demonstração com dados falsos costumam ser
recusados.

## Formas de pagamento
- Pix: para receber, use uma instituição de pagamento/banco com API Pix
  (conta de pessoa jurídica). Confirme o pagamento no servidor, nunca só no app.
- Vale-refeição/alimentação: não pode ser usado para bebida alcoólica. Libere
  apenas para itens sem álcool e tenha contrato com as operadoras.
- Bitcoin/GonCoin: use só como meio de pagamento de produtos. Fixe a cotação
  do pedido por alguns minutos. Sem promessa de lucro ou valorização.
- GonCoin (token próprio) e GonPay (se guardar saldo): consulte advogado ou
  contador sobre regras do Banco Central/CVM e tributação, e leia as políticas
  de serviços financeiros e cripto do Google Play antes de enviar.
- Reflita todos os métodos aceitos na política de privacidade e em Segurança dos dados.

## Comida
- Restaurantes e lanchonetes parceiros precisam de CNPJ e licença sanitária
  (alvará/vigilância sanitária) da prefeitura; peça os documentos no cadastro do lojista.
- Vale-refeição/alimentação vale para comida e itens sem álcool; mantenha o bloqueio
  para bebida alcoólica (já está em createOrder no backend).
- Se uma compra tiver bebida alcoólica, a confirmação de 18+ continua obrigatória.
