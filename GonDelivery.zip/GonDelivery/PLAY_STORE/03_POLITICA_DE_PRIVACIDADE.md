# Política de Privacidade - gon.delivery
Última atualização: [DATA]

Esta política descreve como o gon.delivery ("nós") trata dados pessoais,
conforme a Lei Geral de Proteção de Dados (LGPD - Lei 13.709/2018).

Responsável: [RAZÃO SOCIAL OU SEU NOME], CNPJ/CPF [NÚMERO]
Contato: [SEU E-MAIL]

1. Dados que coletamos (ajuste ao que o app realmente coleta)
- Cadastro: nome, e-mail, telefone, data de nascimento (para confirmar 18+).
- Endereço de entrega e localização aproximada ou precisa, para encontrar
  lojas próximas e entregar o pedido.
- Pedidos: itens, valores e histórico.
- Dados técnicos: modelo do aparelho e registros de erro.
- Pagamentos: processados por GonPay, Pix (via [INSTITUIÇÃO DE PAGAMENTO]) e [PROVEDOR DE PAGAMENTO]; não armazenamos
  número completo de cartão nem dados de vale-refeição além do necessário.
- Pagamentos em criptoativos (Bitcoin e GonCoin): endereço da carteira usada,
  identificador (hash) e valor da transação. Nunca pedimos nem guardamos
  chaves privadas ou frase de recuperação da sua carteira.

2. Para que usamos
Processar e entregar pedidos, verificar maioridade, prestar suporte,
prevenir fraudes e cumprir obrigações legais.

3. Compartilhamento
Com lojas parceiras e entregadores (apenas o necessário para o pedido),
provedores de pagamento (GonPay, Pix, operadoras de cartão e de vale-refeição,
[PROVEDOR DE CRIPTO]) e de infraestrutura [EX.: Google Firebase]. Não vendemos
dados pessoais. Transações em blockchain são públicas e irreversíveis e não
podem ser apagadas por nós.

4. Retenção
Mantemos os dados enquanto a conta estiver ativa e pelo prazo exigido por lei.

5. Seus direitos (LGPD)
Acessar, corrigir, excluir, portar dados e revogar consentimento pelo
e-mail [SEU E-MAIL].

6. Exclusão de conta
Para excluir a conta e os dados, solicite em [SEU E-MAIL] ou [LINK/TELA NO APP].

7. Menores de idade
O app é destinado a maiores de 18 anos.

8. Alterações
Podemos atualizar esta política; a versão vigente ficará nesta página.

(Modelo informativo; revise com um advogado antes de publicar.)
