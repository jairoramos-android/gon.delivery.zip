# Formulário "Segurança dos dados" (guia)
Responda conforme o app FINAL. Para o modelo de delivery com conta e localização:

Coleta dados? Sim
Criptografados em trânsito? Sim (use HTTPS)
Usuário pode pedir exclusão? Sim (obrigatório oferecer meio de exclusão)

Tipos provavelmente coletados:
- Informações pessoais: nome, e-mail, telefone (funcionalidade do app, gerenciamento de conta)
- Localização aproximada/precisa (funcionalidade do app)
- Informações financeiras: histórico de compras (funcionalidade do app); dados de cartão só se você os trata
- Informações financeiras: informações de pagamento (incl. Pix) e histórico de compras; endereço de carteira cripto e hash de transação, se coletados
- Identificadores do aparelho, se usar analytics/Firebase

Compartilhados com terceiros? Sim, se usar pagamento, mapas ou Firebase.

Declaração de recursos financeiros: o Play Console tem uma seção "Recursos
financeiros". Responda de acordo com o app final: pagamentos de produtos físicos
em si costumam ser simples; carteira com saldo, GonPay com saldo guardado ou
GonCoin como ativo próprio exigem declarações adicionais e podem exigir licença.

A versão atual de demonstração (sem login, sem localização) não coleta nada,
mas a ficha precisa refletir o app que será enviado.
