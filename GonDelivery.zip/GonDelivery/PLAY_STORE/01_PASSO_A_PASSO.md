# Passo a passo: do projeto ao Google Play Console

## 1. Gerar o arquivo .aab
1. Android Studio: File > Open > pasta GonDelivery. Aceite o Sync do Gradle
   (se pedir, use o "AGP Upgrade Assistant").
2. Troque o applicationId em app/build.gradle.kts (ex.: br.com.seunome.gondelivery).
   Depois de publicado, NÃO dá mais para mudar.
3. Crie o ícone: File > New > Image Asset.
4. Crie a chave: Build > Generate Signed App Bundle > Create new...
   Guarde o .jks e as senhas em lugar seguro (backup!).
   (Opcional: copie keystore.properties.example para keystore.properties
   e preencha; assim `./gradlew bundleRelease` já sai assinado.)
5. Gere: Build > Generate Signed App Bundle > Android App Bundle > release.
   Arquivo: app/release/app-release.aab

Requisito atual: o app precisa ter targetSdk 36 (já configurado).

## 2. Criar o app no Play Console
1. Criar app > nome, idioma (Português - Brasil), App, Gratuito, aceitar declarações.
2. Painel > "Configurar seu app": preencher todas as tarefas
   (use os textos de 02, 03, 04 e 05).
3. Ficha da loja: ícone 512x512 PNG, imagem de destaque 1024x500,
   no mínimo 2 capturas de tela de celular.

## 3. Teste e produção
- Conta pessoal criada após 13/11/2023: é obrigatório um teste fechado com
  pelo menos 12 testadores inscritos por 14 dias seguidos antes de pedir
  acesso à produção. Conta de organização não tem essa exigência.
- Fluxo: Testes > Teste fechado > criar versão > enviar o .aab >
  adicionar e-mails dos testadores > compartilhar o link de inscrição.
  Recrute mais de 12 (alguns desistem).
- Após 14 dias: "Solicitar acesso à produção" e responder o questionário.
- Depois: Produção > Criar versão > enviar para revisão.

## 4. Antes de enviar para revisão
- [ ] App funciona de verdade (sem dados falsos nem botões que não fazem nada)
- [ ] Política de privacidade publicada em uma URL pública
- [ ] Segurança dos dados preenchida (04)
- [ ] Classificação de conteúdo respondida (05)
- [ ] Público-alvo: 18+ (05)
- [ ] Credenciais de teste para o revisor, se houver login (05)
- [ ] Ícone, imagem de destaque e capturas enviados
