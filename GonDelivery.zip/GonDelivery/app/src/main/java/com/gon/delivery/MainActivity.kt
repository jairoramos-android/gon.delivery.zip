package com.gon.delivery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GonApp() }
    }
}

// ---- Dados de exemplo (trocar depois por backend) ----
data class Product(val id: String, val name: String, val price: Double, val category: String)

val products = mutableStateListOf(
    Product("1", "Cerveja Pilsen 350ml", 4.50, "Cervejas"),
    Product("2", "Cerveja Long Neck 330ml", 7.90, "Cervejas"),
    Product("3", "Cerveja Artesanal IPA 500ml", 18.90, "Cervejas"),
    Product("4", "Vinho Tinto 750ml", 39.90, "Vinhos"),
    Product("5", "Vinho Branco 750ml", 42.90, "Vinhos"),
    Product("6", "Refrigerante 2L", 9.50, "Sem álcool"),
    Product("7", "Água Mineral 1,5L", 4.00, "Sem álcool"),
    Product("8", "Gelo 5kg", 12.00, "Sem álcool"),
    Product("9", "X-Burger com Batata", 24.90, "Lanches"),
    Product("10", "Porção de Batata Frita", 22.00, "Lanches"),
    Product("11", "Pizza Calabresa 35cm", 49.90, "Pizzas"),
    Product("12", "Marmita Executiva", 27.90, "Marmitas")
)
val categories = listOf("Todos", "Lanches", "Pizzas", "Marmitas", "Cervejas", "Vinhos", "Sem álcool")
const val DELIVERY_FEE = 5.0

fun brl(v: Double): String = String.format(Locale("pt", "BR"), "R$ %.2f", v)

private val BG = Color(0xFF121416)
private val CARD = Color(0xFF1E2226)
private val ACCENT = Color(0xFF22C55E)

@Composable
fun GonApp() {
    var screen by remember { mutableStateOf("age") }
    val cart = remember { mutableStateMapOf<String, Int>() }
    var info by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var sending by remember { mutableStateOf(false) }
    val subtotal = cart.entries.sumOf { (id, q) -> (products.firstOrNull { it.id == id }?.price ?: 0.0) * q }
    val count = cart.values.sum()

    LaunchedEffect(Unit) {
        Backend.ensureSignedIn { ok ->
            if (ok) Backend.fetchProducts { list ->
                if (list.isNotEmpty()) { cart.clear(); products.clear(); products.addAll(list) }
            }
        }
    }

    Column(Modifier.fillMaxSize().background(BG).systemBarsPadding().padding(16.dp)) {
        when (screen) {
            "age" -> AgeGate(onYes = { screen = "home" })
            "home" -> Home(cart, count, subtotal) { screen = "cart" }
            "cart" -> CartScreen(
                cart, subtotal, error, sending,
                onBack = { screen = "home" },
                onOrder = { method ->
                    sending = true; error = null
                    Backend.createOrder(cart.toMap(), method) { r ->
                        sending = false
                        r.onSuccess { info = it; screen = "track" }
                            .onFailure { error = "Não foi possível criar o pedido. Tente novamente." }
                    }
                }
            )
            else -> Track(info, onNew = { cart.clear(); info = ""; screen = "home" })
        }
    }
}

@Composable
fun AgeGate(onYes: () -> Unit) {
    var denied by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("gon.delivery", color = ACCENT, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text("Você tem 18 anos ou mais?", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(24.dp))
        if (denied) {
            Text(
                "Você precisa ter 18 anos ou mais para acessar o app.",
                color = Color(0xFFFF8A80), textAlign = TextAlign.Center
            )
        } else {
            Button(onClick = onYes, colors = ButtonDefaults.buttonColors(containerColor = ACCENT)) {
                Text("Sim, tenho 18+")
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { denied = true },
                colors = ButtonDefaults.buttonColors(containerColor = CARD)
            ) { Text("Não") }
        }
    }
}

@Composable
fun Home(cart: MutableMap<String, Int>, count: Int, subtotal: Double, onCart: () -> Unit) {
    var cat by remember { mutableStateOf("Todos") }
    val list = products.filter { cat == "Todos" || it.category == cat }

    Text("gon.delivery", color = ACCENT, fontSize = 26.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        categories.forEach { c ->
            Box(
                Modifier.background(if (c == cat) ACCENT else CARD, RoundedCornerShape(20.dp))
                    .clickable { cat = c }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) { Text(c, color = if (c == cat) Color.Black else Color.White, fontSize = 13.sp) }
        }
    }
    Spacer(Modifier.height(12.dp))
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(list) { p ->
            val q = cart[p.id] ?: 0
            Row(
                Modifier.fillMaxWidth().background(CARD, RoundedCornerShape(12.dp)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(p.name, color = Color.White, fontSize = 15.sp)
                    Text(brl(p.price), color = ACCENT, fontSize = 14.sp)
                }
                if (q > 0) {
                    QtyBtn("−") { if (q == 1) cart.remove(p.id) else cart[p.id] = q - 1 }
                    Text("$q", color = Color.White, modifier = Modifier.padding(horizontal = 10.dp))
                }
                QtyBtn("+") { cart[p.id] = q + 1 }
            }
        }
    }
    if (count > 0) {
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onCart, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ACCENT)
        ) { Text("Ver carrinho ($count) · ${brl(subtotal)}", color = Color.Black) }
    }
}

@Composable
fun QtyBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(36.dp).background(Color(0xFF2C343E), RoundedCornerShape(8.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 20.sp) }
}

val paymentMethods = listOf(
    "pix" to "Pix", "cartao" to "Cartão", "vale" to "Vale-refeição",
    "gonpay" to "GonPay", "bitcoin" to "Bitcoin", "goncoin" to "GonCoin"
)

@Composable
fun CartScreen(
    cart: Map<String, Int>, subtotal: Double, error: String?, sending: Boolean,
    onBack: () -> Unit, onOrder: (String) -> Unit
) {
    var method by remember { mutableStateOf("pix") }
    Text("Seu carrinho", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(cart.entries.toList()) { (id, q) ->
            val p = products.firstOrNull { it.id == id }
            if (p != null) Row(Modifier.fillMaxWidth()) {
                Text("${q}x ${p.name}", color = Color.White, modifier = Modifier.weight(1f))
                Text(brl(p.price * q), color = Color.White)
            }
        }
    }
    Text("Forma de pagamento", color = Color.Gray, fontSize = 13.sp)
    Spacer(Modifier.height(6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        paymentMethods.forEach { (key, label) ->
            Box(
                Modifier.background(if (key == method) ACCENT else CARD, RoundedCornerShape(20.dp))
                    .clickable { method = key }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) { Text(label, color = if (key == method) Color.Black else Color.White, fontSize = 13.sp) }
        }
    }
    if (method == "vale") {
        Text("Vale-refeição não vale para bebida alcoólica.", color = Color.Gray, fontSize = 12.sp)
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth()) {
        Text("Entrega", color = Color.Gray, modifier = Modifier.weight(1f)); Text(brl(DELIVERY_FEE), color = Color.Gray)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text("Total", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(brl(subtotal + DELIVERY_FEE), color = ACCENT, fontWeight = FontWeight.Bold)
    }
    if (error != null) Text(error, color = Color(0xFFFF8A80), fontSize = 13.sp)
    Button(
        onClick = { onOrder(method) }, enabled = !sending, modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = ACCENT)
    ) { Text(if (sending) "Enviando..." else "Finalizar pedido", color = Color.Black) }
    Spacer(Modifier.height(6.dp))
    Button(
        onClick = onBack, modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = CARD)
    ) { Text("Continuar comprando") }
}

@Composable
fun Track(info: String, onNew: () -> Unit) {
    val steps = listOf("Pedido recebido", "Em preparo", "A caminho", "Entregue")
    var step by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (step < steps.lastIndex) { delay(3000); step++ } }

    Text("Acompanhe seu pedido", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    if (info.isNotBlank()) { Spacer(Modifier.height(12.dp)); Text(info, color = ACCENT, fontSize = 14.sp) }
    Spacer(Modifier.height(20.dp))
    steps.forEachIndexed { i, s ->
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(16.dp).background(if (i <= step) ACCENT else CARD, RoundedCornerShape(8.dp)))
            Spacer(Modifier.width(12.dp))
            Text(s, color = if (i <= step) Color.White else Color.Gray, fontSize = 17.sp)
        }
    }
    Spacer(Modifier.weight(1f))
    if (step == steps.lastIndex) {
        Button(
            onClick = onNew, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ACCENT)
        ) { Text("Novo pedido", color = Color.Black) }
    }
}
