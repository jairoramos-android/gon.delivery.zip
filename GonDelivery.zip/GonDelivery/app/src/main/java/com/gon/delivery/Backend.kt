package com.gon.delivery

import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.firestore
import com.google.firebase.functions.functions

/** Acesso ao Firebase. Sem google-services.json tudo falha com segurança. */
object Backend {
    private const val REGION = "southamerica-east1"

    /** Login anônimo por enquanto; troque por e-mail/telefone no app final. */
    fun ensureSignedIn(onReady: (Boolean) -> Unit) {
        try {
            val auth = Firebase.auth
            if (auth.currentUser != null) onReady(true)
            else auth.signInAnonymously().addOnCompleteListener { onReady(it.isSuccessful) }
        } catch (e: Exception) {
            onReady(false)
        }
    }

    fun fetchProducts(onResult: (List<Product>) -> Unit) {
        try {
            Firebase.firestore.collection("products")
                .whereEqualTo("active", true)
                .get()
                .addOnSuccessListener { snap ->
                    onResult(snap.documents.mapNotNull { d ->
                        val name = d.getString("name") ?: return@mapNotNull null
                        val price = d.getDouble("price") ?: return@mapNotNull null
                        Product(d.id, name, price, d.getString("category") ?: "Outros")
                    })
                }
                .addOnFailureListener { onResult(emptyList()) }
        } catch (e: Exception) {
            onResult(emptyList())
        }
    }

    /** Cria o pedido no servidor; devolve o texto de instruções de pagamento. */
    fun createOrder(items: Map<String, Int>, method: String, onResult: (Result<String>) -> Unit) {
        try {
            val data = hashMapOf(
                "items" to items.map { hashMapOf("productId" to it.key, "qty" to it.value) },
                "paymentMethod" to method
            )
            Firebase.functions(REGION).getHttpsCallable("createOrder").call(data)
                .addOnSuccessListener { res ->
                    val m = res.data as? Map<*, *>
                    onResult(Result.success((m?.get("instructions") as? String) ?: ""))
                }
                .addOnFailureListener { onResult(Result.failure(it)) }
        } catch (e: Exception) {
            onResult(Result.failure(e))
        }
    }
}
